function previewImage(event) {

    const image =
        document.getElementById("preview");

    if (!image) {
        return;
    }

    if (!event.target.files[0]) {
        return;
    }

    image.src =
        URL.createObjectURL(
            event.target.files[0]
        );

    image.style.display = "block";
}


function drawSalesChart(id) {

    const canvas =
        document.getElementById(id);

    if (!canvas) {
        return;
    }

    const ctx =
        canvas.getContext("2d");

    const values =
        [5, 9, 11, 14, 14, 19];

    const labels =
        [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "Mei",
            "Jun"
        ];


    canvas.width =
        canvas.clientWidth * 2;

    canvas.height =
        300 * 2;

    ctx.scale(2, 2);


    const width =
        canvas.clientWidth;

    const height = 300;

    const padding = 40;

    const max = 25;


    // Garis grafik

    ctx.strokeStyle =
        "#dbe4de";

    ctx.lineWidth = 1;


    for (
        let i = 0;
        i <= 5;
        i++
    ) {

        const y =
            20 +
            (height - 55) *
            (i / 5);

        ctx.beginPath();

        ctx.moveTo(
            padding,
            y
        );

        ctx.lineTo(
            width - 15,
            y
        );

        ctx.stroke();
    }


    // Garis penjualan

    ctx.strokeStyle =
        "#258653";

    ctx.lineWidth = 3;

    ctx.beginPath();


    values.forEach(
        (value, index) => {

            const x =
                padding +
                index *
                (
                    (width -
                    padding -
                    20)
                    /
                    (values.length - 1)
                );


            const y =
                20 +
                (height - 55) -
                (value / max) *
                (height - 55);


            if (index === 0) {

                ctx.moveTo(x, y);

            } else {

                ctx.lineTo(x, y);

            }

        }
    );


    ctx.stroke();


    // Titik

    ctx.fillStyle =
        "#258653";


    values.forEach(
        (value, index) => {

            const x =
                padding +
                index *
                (
                    (width -
                    padding -
                    20)
                    /
                    (values.length - 1)
                );


            const y =
                20 +
                (height - 55) -
                (value / max) *
                (height - 55);


            ctx.beginPath();

            ctx.arc(
                x,
                y,
                4,
                0,
                Math.PI * 2
            );

            ctx.fill();


            ctx.fillStyle =
                "#66756d";

            ctx.font =
                "12px Arial";

            ctx.fillText(
                labels[index],
                x - 10,
                height - 12
            );


            ctx.fillStyle =
                "#258653";

        }

    );

}