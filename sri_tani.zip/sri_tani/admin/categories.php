<?php

require_once "../config.php";

// Cek login admin
if (
    !isset($_SESSION["role"]) ||
    $_SESSION["role"] != "admin"
) {
    header("Location: ../login.php");
    exit;
}

$error = "";
$success = "";


/* =====================================================
   TAMBAH KATEGORI
===================================================== */

if (
    $_SERVER["REQUEST_METHOD"] == "POST" &&
    isset($_POST["tambah_kategori"])
) {

    $nama_kategori =
        trim($_POST["nama_kategori"]);

    if ($nama_kategori == "") {

        $error = "Nama kategori tidak boleh kosong.";

    } else {

        // Cek apakah kategori sudah ada
        $cek = $conn->prepare(
            "SELECT id_kategori
             FROM kategori
             WHERE nama_kategori = ?"
        );

        $cek->bind_param(
            "s",
            $nama_kategori
        );

        $cek->execute();

        $hasil = $cek->get_result();

        if ($hasil->num_rows > 0) {

            $error =
                "Kategori tersebut sudah ada.";

        } else {

            $stmt = $conn->prepare(
                "INSERT INTO kategori
                (nama_kategori)
                VALUES (?)"
            );

            $stmt->bind_param(
                "s",
                $nama_kategori
            );

            if ($stmt->execute()) {

                $success =
                    "Kategori berhasil ditambahkan.";

            } else {

                $error =
                    "Kategori gagal ditambahkan.";
            }

            $stmt->close();
        }

        $cek->close();
    }
}


/* =====================================================
   HAPUS KATEGORI
===================================================== */

if (isset($_GET["hapus"])) {

    $id =
        (int) $_GET["hapus"];

    // Cek apakah kategori sedang digunakan produk
    $cek = $conn->prepare(
        "SELECT COUNT(*) AS total
         FROM produk
         WHERE id_kategori = ?"
    );

    $cek->bind_param(
        "i",
        $id
    );

    $cek->execute();

    $hasil =
        $cek->get_result()
        ->fetch_assoc();

    $cek->close();


    if ($hasil["total"] > 0) {

        $error =
            "Kategori tidak dapat dihapus karena masih digunakan oleh produk.";

    } else {

        $stmt = $conn->prepare(
            "DELETE FROM kategori
             WHERE id_kategori = ?"
        );

        $stmt->bind_param(
            "i",
            $id
        );

        if ($stmt->execute()) {

            $success =
                "Kategori berhasil dihapus.";

        } else {

            $error =
                "Kategori gagal dihapus.";
        }

        $stmt->close();
    }
}


/* =====================================================
   AMBIL DATA KATEGORI
===================================================== */

$result = $conn->query(
    "SELECT *
     FROM kategori
     ORDER BY id_kategori ASC"
);

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Data Kategori - UD Sri Tani Rejeki</title>

<link
rel="stylesheet"
href="../assets/css/style.css">

</head>


<body>

<div class="layout">


<!-- ==================================================
     SIDEBAR
================================================== -->

<aside class="sidebar">

    <div class="brand">

        <img
        src="../assets/images/logo.jpg"
        alt="Logo">

        <div>

            <strong>
                UD Sri Tani Rejeki
            </strong>

            <small>
                Admin Panel
            </small>

        </div>

    </div>


    <nav>

        <a href="dashboard.php">
            ⌂ Dashboard
        </a>

        <a href="products.php">
            ▦ Data Produk
        </a>

        <a
        href="categories.php"
        class="active">

            ◫ Kategori

        </a>

        <a href="orders.php">
            ▤ Pesanan
        </a>

        <a href="customers.php">
            ♙ Data Pelanggan
        </a>

        <a href="reports.php">
            ▥ Laporan Penjualan
        </a>

        <a href="../tentang_kami.php">
            ⓘ Tentang Kami
        </a>

        <a href="../logout.php">
            ⇥ Keluar
        </a>

    </nav>

</aside>


<!-- ==================================================
     MAIN
================================================== -->

<main class="main">


<!-- TOPBAR -->

<header class="topbar">

    <div class="search">

        🔎

        <input
        type="text"
        placeholder="Cari kategori...">

    </div>


    <div class="user">

        👤 Admin

    </div>

</header>


<!-- CONTENT -->

<section class="content">


<div class="page-title row">

    <div>

        <h1>
            Data Kategori
        </h1>

        <p>
            Kelola kategori produk pertanian.
        </p>

    </div>

</div>


<!-- ==================================================
     NOTIFIKASI
================================================== -->

<?php if ($success): ?>

<div class="alert"
style="
background:#e8f7ed;
color:#207044;
margin-bottom:20px;
">

    <?= htmlspecialchars($success) ?>

</div>

<?php endif; ?>


<?php if ($error): ?>

<div class="alert danger">

    <?= htmlspecialchars($error) ?>

</div>

<?php endif; ?>


<!-- ==================================================
     FORM TAMBAH KATEGORI
================================================== -->

<div class="form-card"
style="max-width:600px; margin-bottom:25px;">

    <h2>
        Tambah Kategori
    </h2>

    <p class="muted">
        Masukkan nama kategori produk baru.
    </p>


    <form method="POST">

        <label>
            Nama Kategori
        </label>

        <input
        type="text"
        name="nama_kategori"
        placeholder="Contoh: Pupuk"
        required>


        <button
        type="submit"
        name="tambah_kategori"
        class="btn primary"
        style="margin-top:15px;">

            + Tambah Kategori

        </button>

    </form>

</div>


<!-- ==================================================
     TABEL KATEGORI
================================================== -->

<div class="table-card">

    <div
    class="panel-head">

        <h2>
            Daftar Kategori
        </h2>

        <span>
            <?= $result->num_rows ?> kategori
        </span>

    </div>


    <table>

        <thead>

            <tr>

                <th>
                    No
                </th>

                <th>
                    Nama Kategori
                </th>

                <th>
                    Aksi
                </th>

            </tr>

        </thead>


        <tbody>

        <?php

        $no = 1;

        while (
            $kategori =
            $result->fetch_assoc()
        ):

        ?>

            <tr>

                <td>
                    <?= $no++ ?>
                </td>


                <td>

                    <strong>

                        <?= htmlspecialchars(
                            $kategori["nama_kategori"]
                        ) ?>

                    </strong>

                </td>


                <td>

                    <a
                    href="categories.php?hapus=
                    <?= $kategori["id_kategori"] ?>"
                    class="danger-link"
                    onclick="
                    return confirm(
                        'Yakin ingin menghapus kategori ini?'
                    );
                    ">

                        Hapus

                    </a>

                </td>

            </tr>


        <?php endwhile; ?>


        <?php if ($result->num_rows == 0): ?>

            <tr>

                <td
                colspan="3"
                style="text-align:center;">

                    Belum ada kategori.

                </td>

            </tr>

        <?php endif; ?>

        </tbody>

    </table>

</div>


</section>

</main>

</div>

</body>

</html>