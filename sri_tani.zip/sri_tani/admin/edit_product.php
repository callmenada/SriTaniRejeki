<?php

require_once "../config.php";

// Cek login admin
if (
    !isset($_SESSION["role"]) ||
    $_SESSION["role"] != "admin"
) {
    header("Location: ../login.php");
    exit;
}


// Cek ID produk
if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    header("Location: products.php");
    exit;
}

$id = (int) $_GET["id"];


// Ambil data produk
$stmt = $conn->prepare("
    SELECT *
    FROM produk
    WHERE id = ?
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Produk tidak ditemukan.";
    exit;
}

$product = $result->fetch_assoc();


// Ambil kategori
$categories = $conn->query("
    SELECT *
    FROM kategori
    ORDER BY nama_kategori ASC
");


$error = "";


// =====================================
// PROSES UPDATE
// =====================================

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["nama_produk"]);
    $category_id = (int) $_POST["id_kategori"];
    $price = (float) $_POST["harga"];
    $stock = (int) $_POST["stok"];
    $description = trim($_POST["deskripsi"]);

    // Gunakan foto lama terlebih dahulu
    $imagePath = $product["image"];


    // =====================================
    // CEK FOTO BARU
    // =====================================

    if (
        isset($_FILES["image"]) &&
        $_FILES["image"]["error"] != UPLOAD_ERR_NO_FILE
    ) {

        if (
            $_FILES["image"]["error"] != UPLOAD_ERR_OK
        ) {

            $error = "Foto gagal diupload.";

        } else {

            $allowed = [
                "jpg",
                "jpeg",
                "png",
                "webp"
            ];

            $extension = strtolower(
                pathinfo(
                    $_FILES["image"]["name"],
                    PATHINFO_EXTENSION
                )
            );


            // Cek format
            if (!in_array($extension, $allowed)) {

                $error =
                    "Format foto harus JPG, JPEG, PNG, atau WEBP.";

            }

            // Cek ukuran
            elseif (
                $_FILES["image"]["size"] >
                2 * 1024 * 1024
            ) {

                $error =
                    "Ukuran foto maksimal 2 MB.";

            }

            else {

                // Nama file baru
                $newName =
                    uniqid("produk_") .
                    "." .
                    $extension;

                $target =
                    "../uploads/" .
                    $newName;


                // Upload foto
                if (
                    move_uploaded_file(
                        $_FILES["image"]["tmp_name"],
                        $target
                    )
                ) {

                    /*
                    =================================
                    HAPUS FOTO LAMA
                    =================================
                    */

                    if (
                        !empty($product["image"]) &&
                        file_exists(
                            "../" .
                            $product["image"]
                        )
                    ) {

                        unlink(
                            "../" .
                            $product["image"]
                        );
                    }


                    // Simpan lokasi foto baru
                    $imagePath =
                        "uploads/" .
                        $newName;

                } else {

                    $error =
                        "Foto baru gagal disimpan.";

                }
            }
        }
    }


    // =====================================
    // UPDATE DATABASE
    // =====================================

    if (!$error) {

        $update = $conn->prepare("
            UPDATE products
            SET
                name = ?,
                category_id = ?,
                price = ?,
                stock = ?,
                description = ?,
                image = ?
            WHERE id = ?
        ");

        $update->bind_param(
            "sidissi",
            $name,
            $category_id,
            $price,
            $stock,
            $description,
            $imagePath,
            $id
        );


        if ($update->execute()) {

            header(
                "Location: products.php"
            );

            exit;

        } else {

            $error =
                "Data produk gagal diperbarui.";

        }
    }
}

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Edit Produk - UD Sri Tani Rejeki</title>

<link
rel="stylesheet"
href="../assets/css/style.css">

</head>


<body>

<div class="layout">


<!-- ================================= -->
<!-- SIDEBAR -->
<!-- ================================= -->

<aside class="sidebar">

    <div class="brand">

        <img
        src="../assets/images/logo.jpg"
        alt="Logo">

        <div>

            <strong>
                UD Sri Tani Rejeki
            </strong>

            <small>
                Admin Panel
            </small>

        </div>

    </div>


    <nav>

        <a href="dashboard.php">
            ⌂ Dashboard
        </a>

        <a
        class="active"
        href="products.php">
            ▦ Data Produk
        </a>

        <a href="categories.php">
            ◫ Kategori
        </a>

        <a href="orders.php">
            ▤ Pesanan
        </a>

        <a href="customers.php">
            ♙ Data Pelanggan
        </a>

        <a href="reports.php">
            ▥ Laporan Penjualan
        </a>

        <a href="../tentang_kami.php">
            ⓘ Tentang Kami
        </a>

        <a href="../logout.php">
            ⇥ Keluar
        </a>

    </nav>

</aside>



<!-- ================================= -->
<!-- MAIN -->
<!-- ================================= -->

<main class="main">


<header class="topbar">

    <div class="search">

        🔎

        <input
        type="text"
        placeholder="Cari produk...">

    </div>


    <div class="user">

        👤 Admin

    </div>

</header>



<section class="content">


<!-- ================================= -->
<!-- JUDUL -->
<!-- ================================= -->

<div class="page-title">

    <h1>
        Edit Produk
    </h1>

    <p>
        Ubah informasi produk yang sudah tersimpan.
    </p>

</div>



<!-- ================================= -->
<!-- FORM -->
<!-- ================================= -->

<div class="form-card">


<?php if ($error): ?>

    <div class="alert danger">

        <?= htmlspecialchars($error) ?>

    </div>

<?php endif; ?>



<form
method="POST"
enctype="multipart/form-data">


<!-- NAMA -->

<label>
    Nama Produk
</label>

<input
type="text"
name="name"
value="<?= htmlspecialchars($product["nama_produk"]) ?>"
placeholder="Nama produk"
required>



<!-- KATEGORI -->

<label>
    Kategori
</label>

<select
name="category_id"
required>

    <option value="">
        Pilih Kategori
    </option>


    <?php while (
        $category =
        $categories->fetch_assoc()
    ): ?>

        <option
        value="<?= $category["id_kategori"] ?>"
        <?= (
            $category["id_kategori"]
            == $product["id"]
        )
        ? "selected"
        : ""
        ?>>

            <?= htmlspecialchars(
                $category["nama_kategori"]
            ) ?>

        </option>

    <?php endwhile; ?>

</select>



<!-- HARGA -->

<label>
    Harga
</label>

<input
type="number"
name="price"
min="0"
value="<?= $product["harga"] ?>"
required>



<!-- STOK -->

<label>
    Stok
</label>

<input
type="number"
name="stock"
min="0"
value="<?= $product["stok"] ?>"
required>



<!-- FOTO LAMA -->

<label>
    Foto Produk Saat Ini
</label>


<div>

<?php if (!empty($product["image"])): ?>

    <img
    src="../<?= htmlspecialchars(
        $product["image"]
    ) ?>"
    class="image-preview"
    id="oldImage"
    alt="Foto Produk">

<?php else: ?>

    <p class="muted">
        Produk belum memiliki foto.
    </p>

<?php endif; ?>

</div>



<!-- FOTO BARU -->

<label>
    Ganti Foto Produk
</label>

<input
type="file"
name="image"
accept="image/jpeg,image/png,image/webp"
onchange="previewEditImage(event)">


<p class="muted">
Kosongkan jika tidak ingin mengganti foto.
</p>


<!-- PREVIEW FOTO BARU -->

<img
id="newPreview"
class="image-preview"
style="display:none;"
alt="Preview Foto Baru">



<!-- DESKRIPSI -->

<label>
    Deskripsi Produk
</label>

<textarea
name="description"
rows="5"
placeholder="Deskripsi produk..."><?= htmlspecialchars(
    $product["deskripsi"]
) ?></textarea>



<!-- BUTTON -->

<div class="row gap">

    <a
    href="products.php"
    class="btn secondary">

        Batal

    </a>


    <button
    type="submit"
    class="btn primary">

        Simpan Perubahan

    </button>

</div>


</form>

</div>

</section>

</main>

</div>



<script>

function previewEditImage(event) {

    const preview =
        document.getElementById(
            "newPreview"
        );

    const file =
        event.target.files[0];


    if (!file) {

        preview.style.display =
            "none";

        return;
    }


    preview.src =
        URL.createObjectURL(file);

    preview.style.display =
        "block";
}

</script>


</body>

</html>