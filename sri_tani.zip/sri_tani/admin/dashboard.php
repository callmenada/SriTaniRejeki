<?php

require_once "../config.php";

if (
    !isset($_SESSION["role"]) ||
    $_SESSION["role"] != "admin"
) {
    header("Location: ../login.php");
    exit;
}

$result = $conn->query(
    "SELECT COUNT(*) AS total FROM produk"
);

$data = $result->fetch_assoc();

$total_produk = $data["total"];

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Dashboard Admin</title>

<link rel="stylesheet"
href="../assets/css/style.css">

</head>

<body>

<div class="layout">

<!-- SIDEBAR -->

<aside class="sidebar">

<div class="brand">

<img
src="../assets/images/logo.jpg">

<div>

<strong>
UD Sri Tani Rejeki
</strong>

<small>
Admin Panel
</small>

</div>

</div>

<nav>

<a class="active"
href="dashboard.php">

⌂ Dashboard

</a>

<a href="products.php">

▦ Data Produk

</a>

<a href="categories.php">

◫ Kategori

</a>

<a href="orders.php">

▤ Pesanan

</a>

<a href="customers.php">

♙ Data Pelanggan

</a>

<a href="reports.php">

▥ Laporan Penjualan

</a>

<a href="../tentang_kami.php">

ⓘ Tentang Kami

</a>

<a href="../logout.php">

⇥ Keluar

</a>

</nav>

</aside>


<!-- MAIN -->

<main class="main">

<header class="topbar">

<div class="search">

🔎

<input
placeholder="Cari produk, pesanan, atau pelanggan...">

</div>

<div class="user">

👤 Admin

</div>

</header>


<section class="content">

<div class="page-title">

<h1>
Selamat Datang, Admin!
</h1>

<p>
Berikut ringkasan aktivitas toko pertanian hari ini.
</p>

</div>


<!-- STATISTIK -->

<div class="stats">

<div class="stat">

<span>📦</span>

<small>Total Produk</small>

<b>
<?= $total_produk ?>
</b>

<em>
Produk aktif
</em>

</div>


<div class="stat">

<span>🛍</span>

<small>Total Pesanan</small>

<b>
247
</b>

<em>
↑ 12% dari bulan lalu
</em>

</div>


<div class="stat">

<span>◷</span>

<small>Pesanan Diproses</small>

<b>
32
</b>

<em>
↑ 8% dari bulan lalu
</em>

</div>


<div class="stat">

<span>Rp</span>

<small>Total Pendapatan</small>

<b>
Rp 18.750.000
</b>

<em>
↑ 15% dari bulan lalu
</em>

</div>

</div>


<!-- DASHBOARD -->

<div class="dashboard-grid">


<div class="panel wide">

<div class="panel-head">

<h2>
Grafik Penjualan
</h2>

<span>
6 bulan terakhir
</span>

</div>

<canvas id="salesChart"></canvas>

</div>


<div class="panel">

<div class="panel-head">

<h2>
Produk Terlaris
</h2>

<a href="products.php">
Lihat Semua
</a>

</div>

<ul class="rank-list">

<li>
Pupuk NPK 16-16-16
<b>523</b>
</li>

<li>
Metsulindo Plus 80 WP
<b>412</b>
</li>

<li>
Lae Up
<b>125</b>
</li>

<li>
Pupuk Ultradap
<b>295</b>
</li>

<li>
Bhirawa
<b>89</b>
</li>

</ul>

</div>


<div class="panel">

<div class="panel-head">

<h2>
Stok Menipis
</h2>

<a href="products.php">
Lihat Semua
</a>

</div>

<ul class="stock-list">

<li>
Noxone
<b>5 pcs</b>
</li>

<li>
Furadan 3 GR
<b>8 pcs</b>
</li>

<li>
Dangke
<b>12 pcs</b>
</li>

<li>
Metindo
<b>15 pcs</b>
</li>

<li>
Klopindo
<b>20 pcs</b>
</li>

</ul>

</div>

</div>

</section>

</main>

</div>

<script src="../assets/js/app.js"></script>

<script>

drawSalesChart("salesChart");

</script>

</body>

</html>