<?php

require_once "../config.php";

if (
    !isset($_SESSION["role"]) ||
    $_SESSION["role"] != "admin"
) {
    header("Location: ../login.php");
    exit;
}

$result = $conn->query("
SELECT
produk.*,
kategori AS nama_kategori

FROM produk



ORDER BY produk.id DESC
");

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Data Produk</title>

<link rel="stylesheet"
href="../assets/css/style.css">

</head>

<body>

<div class="layout">

<aside class="sidebar">

<div class="brand">

<img src="../assets/images/logo.jpg">

<div>

<strong>
UD Sri Tani Rejeki
</strong>

<small>
Admin Panel
</small>

</div>

</div>

<nav>

<a href="dashboard.php">
⌂ Dashboard
</a>

<a class="active"
href="products.php">
▦ Data Produk
</a>

<a href="categories.php">
◫ Kategori
</a>

<a href="orders.php">
▤ Pesanan
</a>

<a href="customers.php">
♙ Data Pelanggan
</a>

<a href="reports.php">
▥ Laporan
</a>

<a href="../tentang_kami.php">
ⓘ Tentang Kami
</a>

<a href="../logout.php">
⇥ Keluar
</a>

</nav>

</aside>


<main class="main">

<header class="topbar">

<div class="search">

🔎

<input
placeholder="Cari produk...">

</div>

<div class="user">

👤 Admin

</div>

</header>


<section class="content">

<div class="page-title row">

<div>

<h1>
Data Produk
</h1>

<p>
Kelola produk dan foto produk.
</p>

</div>

<a
href="add_product.php"
class="btn primary">

+ Tambah Produk

</a>

</div>


<div class="table-card">

<table>

<thead>

<tr>

<th>Foto</th>

<th>Nama Produk</th>

<th>Kategori</th>

<th>Harga</th>

<th>Stok</th>

<th>Aksi</th>

</tr>

</thead>

<tbody>

<?php while (
$product = $result->fetch_assoc()
): ?>

<tr>

<td>

<?php if (!empty($product["foto"])): ?>

    <img
        class="thumb"
        src="../assets/images/<?= htmlspecialchars($product["foto"]) ?>"
        alt="<?= htmlspecialchars($product["nama_produk"]) ?>">

<?php else: ?>

    <img
        class="thumb"
        src="../assets/images/logo.jpg"
        alt="Tidak ada foto">

<?php endif; ?>

</td>

<td>

<?= htmlspecialchars(
$product["nama_produk"]
) ?>

</td>

<td>

<?= htmlspecialchars(
$product["nama_kategori"] ?? "-"
) ?>

</td>

<td>

Rp
<?= number_format(
$product["harga"],
0,
",",
"."
) ?>

</td>

<td>

<?= $product["stok"] ?>

</td>

<td>

<a
href="edit_product.php?id=
<?= $product["id"] ?>">

Edit

</a>

|

<a
class="danger-link"
onclick="return confirm('Hapus produk?')"
href="delete_product.php?id=
<?= $product["id"] ?>">

Hapus

</a>

</td>

</tr>

<?php endwhile; ?>

</tbody>

</table>

</div>

</section>

</main>

</div>

</body>

</html>