<?php

require_once "../config.php";

if (
    !isset($_SESSION["role"]) ||
    $_SESSION["role"] != "admin"
) {
    header("Location: ../login.php");
    exit;
}

$categories = $conn->query(
    "SELECT * FROM kategori ORDER BY nama_kategori "
);

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"]);

    $category_id =
        (int) $_POST["category_id"];

    $price =
        (float) $_POST["price"];

    $stock =
        (int) $_POST["stock"];

    $description =
        trim($_POST["description"]);

    $imagePath = "";


    /*
    ==================================
    UPLOAD FOTO PRODUK
    ==================================
    */

    if (
        isset($_FILES["image"]) &&
        $_FILES["image"]["error"] == 0
    ) {

        $allowed = [
            "jpg",
            "jpeg",
            "png",
            "webp"
        ];

        $extension =
            strtolower(
                pathinfo(
                    $_FILES["image"]["name"],
                    PATHINFO_EXTENSION
                )
            );


        if (
            !in_array(
                $extension,
                $allowed
            )
        ) {

            $error =
                "Format foto harus JPG, JPEG, PNG, atau WEBP.";

        }

        elseif (
            $_FILES["image"]["size"]
            > 2 * 1024 * 1024
        ) {

            $error =
                "Ukuran foto maksimal 2 MB.";

        }

        else {

            $newName =
                uniqid("produk_")
                . "."
                . $extension;

            $target =
                "../uploads/"
                . $newName;


            if (
                move_uploaded_file(
                    $_FILES["image"]["tmp_name"],
                    $target
                )
            ) {

                $imagePath =
                    "uploads/"
                    . $newName;

            }

            else {

                $error =
                    "Foto gagal diupload.";

            }

        }

    }


    if (!$error) {

        $query = $conn->prepare("
            INSERT INTO products
            (
                name,
                category_id,
                price,
                stock,
                description,
                image
            )
            VALUES
            (?, ?, ?, ?, ?, ?)
        ");

        $query->bind_param(
            "sidiss",
            $name,
            $category_id,
            $price,
            $stock,
            $description,
            $imagePath
        );

        $query->execute();

        header(
            "Location: products.php"
        );

        exit;
    }

}

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Tambah Produk</title>

<link rel="stylesheet"
href="../assets/css/style.css">

</head>

<body>

<div class="layout">

<aside class="sidebar">

<div class="brand">

<img src="../assets/images/logo.jpg">

<div>

<strong>
UD Sri Tani Rejeki
</strong>

<small>
Admin Panel
</small>

</div>

</div>

<nav>

<a href="dashboard.php">
⌂ Dashboard
</a>

<a class="active"
href="products.php">
▦ Data Produk
</a>

<a href="categories.php">
◫ Kategori
</a>

<a href="orders.php">
▤ Pesanan
</a>

<a href="../tentang_kami.php">
ⓘ Tentang Kami
</a>

<a href="../logout.php">
⇥ Keluar
</a>

</nav>

</aside>


<main class="main">

<header class="topbar">

<div class="search">

🔎

<input
placeholder="Cari...">

</div>

<div class="user">
👤 Admin
</div>

</header>


<section class="content">

<div class="page-title">

<h1>
Tambah Produk
</h1>

<p>
Tambahkan data dan foto produk.
</p>

</div>


<div class="form-card">

<?php if ($error): ?>

<div class="alert danger">

<?= htmlspecialchars($error) ?>

</div>

<?php endif; ?>


<form
method="POST"
enctype="multipart/form-data">


<label>
Nama Produk
</label>

<input
type="text"
name="name"
placeholder="Contoh: Pupuk NPK 16-16-16"
required>


<label>
Kategori
</label>

<select
name="category_id"
required>

<option value="">
Pilih Kategori
</option>

<?php while (
$category =
$categories->fetch_assoc()
): ?>

<option
value="<?= $category["id"] ?>">

<?= htmlspecialchars(
$category["name"]
) ?>

</option>

<?php endwhile; ?>

</select>


<label>
Harga
</label>

<input
type="number"
name="price"
min="0"
required>


<label>
Stok
</label>

<input
type="number"
name="stock"
min="0"
required>


<label>
Foto Produk
</label>

<input
type="file"
name="image"
accept="image/jpeg,image/png,image/webp"
onchange="previewImage(event)"
required>


<img
id="preview"
class="image-preview"
alt="Preview">


<label>
Deskripsi Produk
</label>

<textarea
name="description"
rows="5"
placeholder="Deskripsi produk..."></textarea>


<div class="row gap">

<a
href="products.php"
class="btn secondary">

Batal

</a>

<button
type="submit"
class="btn primary">

Simpan Produk

</button>

</div>


</form>

</div>

</section>

</main>

</div>


<script
src="../assets/js/app.js">
</script>

</body>

</html>