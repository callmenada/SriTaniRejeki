<?php

require_once "config.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST["email"];
    $password = $_POST["password"];

    // LOGIN ADMIN
    if (
        $email == "admin@sritani.test" &&
        $password == "admin123"
    ) {

        $_SESSION["role"] = "admin";
        $_SESSION["nama"] = "Admin";

        header("Location: admin/dashboard.php");
        exit;
    }

    // LOGIN PELANGGAN
    if (
        $email == "pelanggan@sritani.test" &&
        $password == "pelanggan123"
    ) {

        $_SESSION["role"] = "customer";
        $_SESSION["nama"] = "Siti Nurhaliza";

        if (!isset($_SESSION["cart"])) {
            $_SESSION["cart"] = [];
        }

        header("Location: customer/dashboard.php");
        exit;
    }

    $error = "Email atau password salah.";
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Login - UD Sri Tani Rejeki</title>

<link rel="stylesheet"
href="assets/css/style.css">

</head>

<body class="login-page">

<div class="login-card">

<img
src="assets/images/logo.jpg"
class="login-logo"
alt="UD Sri Tani Rejeki">

<h1>UD Sri Tani Rejeki</h1>

<p class="muted">
Toko Pertanian Terpercaya
</p>

<?php if ($error): ?>

<div class="alert danger">

<?= htmlspecialchars($error) ?>

</div>

<?php endif; ?>

<form method="POST">

<label>Email</label>

<input
type="email"
name="email"
placeholder="Masukkan email"
required>

<label>Password</label>

<input
type="password"
name="password"
placeholder="Masukkan password"
required>

<button
type="submit"
class="btn primary full">

Masuk

</button>

</form>

<div class="demo-box">

<strong>Login Admin</strong><br>

admin@sritani.test<br>
admin123

<br><br>

<strong>Login Pelanggan</strong><br>

pelanggan@sritani.test<br>
pelanggan123

</div>

</div>

</body>

</html>