<?php

require_once "../config.php";

// ==========================================
// CEK LOGIN CUSTOMER
// ==========================================

if (
    !isset($_SESSION["role"]) ||
    $_SESSION["role"] !== "customer"
) {

    header("Location: ../login.php");
    exit;

}


// ==========================================
// AMBIL DATA KATEGORI
// ==========================================

$result = $conn->query("
    SELECT *
    FROM kategori
    ORDER BY id_kategori ASC
");

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Kategori - UD Sri Tani Rejeki
    </title>


    <!-- CSS UTAMA -->

    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >


    <!-- CSS KHUSUS KATEGORI -->

    <style>

        /* =====================================
           CATEGORY HEADER
        ===================================== */

        .category-header {

            margin-bottom: 30px;

        }


        .category-header h1 {

            margin: 0 0 8px 0;

            font-size: 30px;

            color: #173b2b;

        }


        .category-header p {

            margin: 0;

            color: #777;

            font-size: 15px;

        }



        /* =====================================
           CATEGORY GRID
        ===================================== */

        .category-grid {

            display: grid;

            grid-template-columns:
                repeat(4, 1fr);

            gap: 20px;

        }



        /* =====================================
           CATEGORY CARD
        ===================================== */

        .category-card {

            background: #ffffff;

            border: 1px solid #e5e9e6;

            border-radius: 16px;

            padding: 25px 20px;

            text-decoration: none;

            color: #173b2b;

            transition: 0.25s;

            display: block;

            text-align: center;

        }


        .category-card:hover {

            transform:
                translateY(-5px);

            box-shadow:
                0 10px 25px
                rgba(0, 0, 0, 0.08);

            border-color: #2b8a5a;

        }



        /* =====================================
           CATEGORY ICON
        ===================================== */

        .category-icon {

            width: 75px;

            height: 75px;

            margin: 0 auto 15px;

            border-radius: 50%;

            background: #eaf5ed;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 35px;

        }



        /* =====================================
           CATEGORY NAME
        ===================================== */

        .category-card h3 {

            margin: 0 0 8px;

            font-size: 18px;

        }


        .category-card p {

            margin: 0;

            color: #777;

            font-size: 13px;

        }



        /* =====================================
           EMPTY
        ===================================== */

        .empty-category {

            background: #ffffff;

            border-radius: 15px;

            padding: 60px 30px;

            text-align: center;

            grid-column: 1 / -1;

        }


        .empty-category h3 {

            margin-bottom: 10px;

        }


        .empty-category p {

            color: #777;

        }



        /* =====================================
           RESPONSIVE
        ===================================== */

        @media (max-width: 1100px) {

            .category-grid {

                grid-template-columns:
                    repeat(3, 1fr);

            }

        }


        @media (max-width: 800px) {

            .category-grid {

                grid-template-columns:
                    repeat(2, 1fr);

            }

        }


        @media (max-width: 500px) {

            .category-grid {

                grid-template-columns: 1fr;

            }

        }

    </style>

</head>


<body>


<div class="layout">


    <!-- ==========================================
         SIDEBAR
    =========================================== -->

    <aside class="sidebar">


        <!-- BRAND -->

        <div class="brand">


            <img
                src="../assets/images/Sawitri.jpg"
                alt="Logo UD Sri Tani Rejeki"
            >


            <div>

                <strong>
                    UD Sri Tani Rejeki
                </strong>

                <small>
                    Solusi Pertanian Anda
                </small>

            </div>


        </div>



        <!-- MENU -->

        <nav>


            <!-- BERANDA -->

            <a href="dashboard.php">

                🏠
                Beranda

            </a>



            <!-- PRODUK -->

            <a href="produk.php">

                ▦
                Produk

            </a>



            <!-- KATEGORI -->

            <a
                href="kategori.php"
                class="active"
            >

                ◫
                Kategori

            </a>



            <!-- KERANJANG -->

            <a href="keranjang.php">

                🛒
                Keranjang

            </a>



            <!-- PESANAN -->

            <a href="keranjang.php">

                📋
                Pesanan Saya

            </a>



            <!-- RIWAYAT -->

            <a href="keranjang.php">

                🕘
                Riwayat Pesanan

            </a>



            <!-- TENTANG KAMI -->

            <a href="../tentang_kami.php">

                ⓘ
                Tentang Kami

            </a>



            <!-- LOGOUT -->

            <a href="../logout.php">

                ⇥
                Keluar

            </a>


        </nav>



        <!-- PROMO -->

        <div class="side-promo">


            <b>

                Bersama Kita Dukung
                Pertanian Indonesia

            </b>


            <a href="produk.php">

                Belanja Sekarang →

            </a>


        </div>


    </aside>



    <!-- ==========================================
         MAIN
    =========================================== -->

    <main class="main">


        <!-- ======================================
             TOPBAR
        ======================================= -->

        <header class="topbar">


            <!-- SEARCH -->

            <form
                action="produk.php"
                method="GET"
                class="search"
            >

                🔎


                <input
                    type="text"
                    name="search"
                    placeholder="Cari produk, benih, pupuk, alat pertanian..."
                >


            </form>



            <!-- USER -->

            <div class="user">


                🔔


                <a
                    href="keranjang.php"
                    style="text-decoration:none;"
                >

                    🛒

                </a>


                👤


                <?= htmlspecialchars(
                    $_SESSION["nama"] ?? "Pelanggan"
                ) ?>


            </div>


        </header>



        <!-- ======================================
             CONTENT
        ======================================= -->

        <section class="content">


            <!-- HEADER -->

            <div class="category-header">


                <h1>

                    Kategori Produk

                </h1>


                <p>

                    Pilih kategori produk pertanian
                    yang Anda butuhkan.

                </p>


            </div>



            <!-- ==================================
                 CATEGORY GRID
            =================================== -->

            <div class="category-grid">


                <?php if (
                    $result &&
                    $result->num_rows > 0
                ): ?>


                    <?php while (
                        $category = $result->fetch_assoc()
                    ): ?>


                        <?php

                        /*
                         * Menentukan icon berdasarkan
                         * nama kategori.
                         */

                        $categoryName =
                            strtolower(
                                $category["name"] ?? ""
                            );


                        $icon = "🌱";


                        if (
                            strpos(
                                $categoryName,
                                "pupuk"
                            ) !== false
                        ) {

                            $icon = "🌿";

                        }

                        elseif (
                            strpos(
                                $categoryName,
                                "benih"
                            ) !== false ||
                            strpos(
                                $categoryName,
                                "bibit"
                            ) !== false
                        ) {

                            $icon = "🌱";

                        }

                        elseif (
                            strpos(
                                $categoryName,
                                "alat"
                            ) !== false
                        ) {

                            $icon = "🛠️";

                        }

                        elseif (
                            strpos(
                                $categoryName,
                                "pestisida"
                            ) !== false
                        ) {

                            $icon = "🧴";

                        }

                        elseif (
                            strpos(
                                $categoryName,
                                "pertanian"
                            ) !== false
                        ) {

                            $icon = "🚜";

                        }

                        ?>


                        <!-- CATEGORY CARD -->

                        <a
                            href="produk.php?kategori=<?= (int)$category["id_kategori"] ?>"
                            class="category-card"
                        >


                            <div class="category-icon">

                                <?= $icon ?>

                            </div>


                            <h3>

                                <?= htmlspecialchars(
                                    $category["name"] ?? "Kategori"
                                ) ?>

                            </h3>


                            <p>

                                Lihat produk →

                            </p>


                        </a>


                    <?php endwhile; ?>


                <?php else: ?>


                    <!-- JIKA BELUM ADA KATEGORI -->

                    <div class="empty-category">


                        <h3>

                            Belum Ada Kategori

                        </h3>


                        <p>

                            Kategori produk belum
                            tersedia.

                        </p>


                    </div>


                <?php endif; ?>


            </div>


        </section>


    </main>


</div>


</body>

</html>