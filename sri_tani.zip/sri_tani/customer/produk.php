<?php

require_once "../config.php";


// ========================================
// CEK LOGIN
// ========================================

if (
    !isset($_SESSION["role"]) ||
    $_SESSION["role"] != "customer"
) {

    header("Location: ../login.php");
    exit;

}


// ========================================
// SEARCH
// ========================================

$search = "";

if (isset($_GET["search"])) {

    $search =
        trim($_GET["search"]);

}


// ========================================
// QUERY PRODUK
// ========================================

if ($search != "") {

    $searchSafe =
        $conn->real_escape_string(
            $search
        );


    $result = $conn->query("
        SELECT *
        FROM produk
        WHERE
            name LIKE '%$searchSafe%'
        ORDER BY id DESC
    ");

} else {

    $result = $conn->query("
        SELECT *
        FROM produk
        ORDER BY id DESC
    ");

}

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Produk - UD Sri Tani Rejeki</title>


<link
    rel="stylesheet"
    href="../assets/css/style.css"
>


<style>

/* ========================================
   PRODUCT PAGE
======================================== */

.product-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 25px;

}


.product-header h1 {

    margin-bottom: 5px;

}


.product-header p {

    color: #777;

}


.product-search {

    display: flex;

    gap: 10px;

    margin-bottom: 25px;

}


.product-search input {

    width: 100%;

    max-width: 500px;

    padding: 13px 16px;

    border: 1px solid #ddd;

    border-radius: 10px;

    outline: none;

}


.product-search button {

    border: none;

    background: #287f52;

    color: white;

    padding: 0 20px;

    border-radius: 10px;

    cursor: pointer;

}


.product-page-grid {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 20px;

}


.product-page-card {

    background: white;

    border-radius: 15px;

    overflow: hidden;

    border: 1px solid #e5e5e5;

    transition: 0.2s;

}


.product-page-card:hover {

    transform:
        translateY(-4px);

    box-shadow:
        0 8px 20px
        rgba(0,0,0,0.08);

}


.product-page-image {

    width: 100%;

    height: 210px;

    background: #f1f4f2;

}


.product-page-image img {

    width: 100%;

    height: 100%;

    object-fit: cover;

}


.product-page-info {

    padding: 17px;

}


.product-page-info h3 {

    margin-bottom: 8px;

    font-size: 17px;

}


.product-page-rating {

    color: #efa92d;

    font-size: 13px;

    margin-bottom: 10px;

}


.product-page-price {

    color: #21804e;

    font-size: 18px;

    font-weight: bold;

    margin-bottom: 15px;

}


.product-page-button {

    display: block;

    text-align: center;

    text-decoration: none;

    background: #298754;

    color: white;

    padding: 11px;

    border-radius: 8px;

}


.empty-product {

    background: white;

    padding: 60px;

    text-align: center;

    border-radius: 15px;

    grid-column: 1 / -1;

}


@media (max-width: 1100px) {

    .product-page-grid {

        grid-template-columns:
            repeat(3, 1fr);

    }

}


@media (max-width: 800px) {

    .product-page-grid {

        grid-template-columns:
            repeat(2, 1fr);

    }

}


@media (max-width: 500px) {

    .product-page-grid {

        grid-template-columns: 1fr;

    }

}

</style>


</head>


<body>


<div class="layout">


<!-- ==================================================
     SIDEBAR
================================================== -->

<aside class="sidebar">


    <div class="brand">


        <img
            src="../assets/images/Logo.jpg"
            alt="Logo"
        >


        <div>

            <strong>
                UD Sri Tani Rejeki
            </strong>

            <small>
                Solusi Pertanian Anda
            </small>

        </div>


    </div>



    <nav>


        <a href="dashboard.php">

            🏠
            Beranda

        </a>


        <a
            href="produk.php"
            class="active"
        >

            ▦
            Produk

        </a>


        <a href="kategori.php">

            ◫
            Kategori

        </a>


        <a href="keranjang.php">

            🛒
            Keranjang

        </a>


        <a href="keranjang.php">

            ▤
            Pesanan Saya

        </a>


        <a href="keranjang.php">

            ◷
            Riwayat Pesanan

        </a>


        <a href="../tentang_kami.php">

            ⓘ
            Tentang Kami

        </a>


        <a href="../logout.php">

            ⇥
            Keluar

        </a>


    </nav>



    <div class="side-promo">

        <b>

            Bersama Kita Dukung
            Pertanian Indonesia

        </b>


        <a href="produk.php">

            Belanja Sekarang →

        </a>

    </div>


</aside>



<!-- ==================================================
     MAIN
================================================== -->

<main class="main">


<header class="topbar">


    <form
        class="search"
        action="produk.php"
        method="GET"
    >

        🔎

        <input
            type="text"
            name="search"
            value="<?= htmlspecialchars($search) ?>"
            placeholder="Cari produk, benih, pupuk, alat pertanian..."
        >

    </form>


    <div class="user">

        🔔

        &nbsp;

        <a
            href="keranjang.php"
            style="text-decoration:none;"
        >
            🛒
        </a>

        &nbsp;

        👤

        <?= htmlspecialchars(
            $_SESSION["nama"] ?? "Pelanggan"
        ) ?>

    </div>


</header>



<section class="content">


<!-- TITLE -->

<div class="product-header">

    <div>

        <h1>
            Produk Pertanian
        </h1>

        <p>
            Temukan berbagai produk
            pertanian berkualitas.
        </p>

    </div>

</div>



<!-- SEARCH -->

<form
    action="produk.php"
    method="GET"
    class="product-search"
>


    <input
        type="text"
        name="search"
        value="<?= htmlspecialchars($search) ?>"
        placeholder="Cari nama produk..."
    >


    <button type="submit">

        🔎 Cari

    </button>


</form>



<!-- PRODUCT GRID -->

<div class="product-page-grid">


<?php if (
    $result &&
    $result->num_rows > 0
): ?>


    <?php while (
        $product = $result->fetch_assoc()
    ): ?>


        <div class="product-page-card">


            <!-- IMAGE -->

            <div class="product-page-image">


                <?php

                $image =
                    $product["image"] ?? "";


                if (
                    !empty($image)
                ) {

                    if (
                        filter_var(
                            $image,
                            FILTER_VALIDATE_URL
                        )
                    ) {

                        $imagePath =
                            $image;

                    }

                    elseif (
                        strpos(
                            $image,
                            "../"
                        ) === 0
                    ) {

                        $imagePath =
                            $image;

                    }

                    else {

                        $imagePath =
                            "../" . $image;

                    }

                }

                else {

                    $imagePath =
                        "../assets/images/Logo.jpg";

                }

                ?>


                <img
                    src="<?= htmlspecialchars(
                        $imagePath
                    ) ?>"
                    alt="<?= htmlspecialchars(
                        $product["name"] ?? "Produk"
                    ) ?>"
                    onerror="this.onerror=null;this.src='../assets/images/Logo.jpg';"
                >


            </div>



            <!-- INFO -->

            <div class="product-page-info">


                <h3>

                    <?= htmlspecialchars(
                        $product["name"] ?? "Produk"
                    ) ?>

                </h3>


                <div class="product-page-rating">

                    ★ 4.8 (20)

                </div>


                <div class="product-page-price">

                    Rp
                    <?= number_format(
                        $product["price"] ?? 0,
                        0,
                        ",",
                        "."
                    ) ?>

                </div>


                <a
                    href="../cart.php?add=<?= (int)$product["id"] ?>"
                    class="product-page-button"
                >

                    + Tambah ke Keranjang

                </a>


            </div>


        </div>


    <?php endwhile; ?>


<?php else: ?>


    <div class="empty-product">

        <h2>
            Produk Tidak Ditemukan
        </h2>

        <p>
            <?php if ($search != ""): ?>

                Tidak ada produk dengan
                kata kunci
                "<b><?= htmlspecialchars($search) ?></b>".

            <?php else: ?>

                Belum ada produk yang tersedia.

            <?php endif; ?>

        </p>

    </div>


<?php endif; ?>


</div>


</section>


</main>


</div>


</body>

</html>