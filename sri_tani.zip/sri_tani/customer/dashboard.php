<?php

require_once "../config.php";

if (
    !isset($_SESSION["role"]) ||
    $_SESSION["role"] != "customer"
) {

    header("Location: ../login.php");

    exit;
}


$result = $conn->query("
    SELECT *
    FROM produk
    ORDER BY id DESC
    LIMIT 8
");

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Beranda Pelanggan</title>

<link rel="stylesheet"
href="../assets/css/style.css">

</head>

<body>

<div class="layout">

<aside class="sidebar">

<div class="brand">

<img src="../assets/images/logo.jpg">

<div>

<strong>
UD Sri Tani Rejeki
</strong>

<small>
Solusi Pertanian Anda
</small>

</div>

</div>


<nav>

<a class="active"
href="dashboard.php">

⌂ Beranda

</a>

<a href="products.php">

▦ Produk

</a>

<a href="categories.php">

◫ Kategori

</a>

<a href="../cart.php">

🛒 Keranjang

</a>

<a href="orders.php">

▤ Pesanan Saya

</a>

<a href="history.php">

◷ Riwayat Pesanan

</a>

<a href="../tentang_kami.php">

ⓘ Tentang Kami

</a>

<a href="../logout.php">

⇥ Keluar

</a>

</nav>


<div class="side-promo">

<b>
Bersama Kita Dukung
Pertanian Indonesia
</b>

<a href="products.php">

Belanja Sekarang →

</a>

</div>

</aside>


<main class="main">

<header class="topbar">

<div class="search">

🔎

<input
placeholder="Cari produk, benih, pupuk, alat pertanian...">

</div>


<div class="user">

🔔 &nbsp;

🛒 &nbsp;

👤

<?= htmlspecialchars(
$_SESSION["nama"]
) ?>

</div>

</header>


<section class="content">


<!-- BANNER -->

<div class="hero">

<div>

<small>
Promo Spesial
</small>

<h1>

Pupuk Organik
<br>

Diskon hingga
<b>25%</b>

</h1>

<p>

Tingkatkan kesuburan tanah
untuk hasil panen yang lebih baik!

</p>

<a
href="products.php"
class="btn primary">

Belanja Sekarang →

</a>

</div>

</div>


<div class="page-title row">

<div>

<h2>
Produk Terbaru
</h2>

<p>
Pilihan produk pertanian untuk Anda.
</p>

</div>

<a href="products.php">
Lihat Semua →
</a>

</div>


<div class="product-grid">


<?php while (
$product =
$result->fetch_assoc()
): ?>


<div class="product-card">


<div class="product-image">

<img
src="<?=

$product["image"]
?
"../".$product["image"]
:
"../assets/images/logo.jpg"

?>">

</div>


<h3>

<?= htmlspecialchars(
$product["name"]
) ?>

</h3>


<p class="rating">

★ 4.8 (20)

</p>


<strong>

Rp
<?= number_format(
$product["price"],
0,
",",
"."
) ?>

</strong>


<a
href="../cart.php?add=
<?= $product["id"] ?>"
class="btn primary full">

+ Keranjang

</a>


</div>


<?php endwhile; ?>


</div>


</section>

</main>

</div>

</body>

</html>