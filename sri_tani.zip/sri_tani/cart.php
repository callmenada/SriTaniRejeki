<?php

require_once "config.php";

if (!isset($_SESSION["role"])) {

    header("Location: login.php");

    exit;
}


if (!isset($_SESSION["cart"])) {

    $_SESSION["cart"] = [];

}


/*
==============================
TAMBAH PRODUK
==============================
*/

if (isset($_GET["add"])) {

    $id = (int) $_GET["add"];

    if (
        isset($_SESSION["cart"][$id])
    ) {

        $_SESSION["cart"][$id]++;

    } else {

        $_SESSION["cart"][$id] = 1;

    }

    header("Location: cart.php");

    exit;
}


/*
==============================
HAPUS PRODUK
==============================
*/

if (isset($_GET["remove"])) {

    $id = (int) $_GET["remove"];

    unset(
        $_SESSION["cart"][$id]
    );

    header("Location: cart.php");

    exit;
}


/*
==============================
UPDATE JUMLAH
==============================
*/

if (
    $_SERVER["REQUEST_METHOD"]
    == "POST"
) {

    if (isset($_POST["qty"])) {

        foreach (
            $_POST["qty"] as $id => $qty
        ) {

            $qty = max(
                1,
                (int) $qty
            );

            $_SESSION["cart"][
                (int)$id
            ] = $qty;
        }
    }

    header("Location: cart.php");

    exit;
}


/*
==============================
AMBIL DATA PRODUK
==============================
*/

$items = [];

$total = 0;


if (
    count($_SESSION["cart"]) > 0
) {

    $ids =
        array_keys(
            $_SESSION["cart"]
        );


    $safeIds =
        implode(
            ",",
            array_map(
                "intval",
                $ids
            )
        );


    $result =
        $conn->query("
            SELECT *
            FROM products
            WHERE id IN ($safeIds)
        ");


    while (
        $product =
        $result->fetch_assoc()
    ) {

        $product["qty"] =
            $_SESSION["cart"][
                $product["id"]
            ];


        $product["subtotal"] =
            $product["qty"]
            *
            $product["price"];


        $total +=
            $product["subtotal"];


        $items[] = $product;
    }
}

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Keranjang Belanja</title>

<link rel="stylesheet"
href="assets/css/style.css">

</head>

<body>

<div class="layout">

<aside class="sidebar">

<div class="brand">

<img src="assets/images/logo.jpg">

<div>

<strong>
UD Sri Tani Rejeki
</strong>

<small>
Toko Pertanian
</small>

</div>

</div>


<nav>

<a href="customer/dashboard.php">

⌂ Beranda

</a>

<a href="customer/products.php">

▦ Produk

</a>

<a class="active"
href="cart.php">

🛒 Keranjang

</a>

<a href="customer/orders.php">

▤ Pesanan Saya

</a>

<a href="tentang_kami.php">

ⓘ Tentang Kami

</a>

<a href="logout.php">

⇥ Keluar

</a>

</nav>

</aside>


<main class="main">

<header class="topbar">

<div class="search">

🔎

<input
placeholder="Cari produk...">

</div>

<div class="user">

👤

<?= htmlspecialchars(
$_SESSION["nama"] ?? "Pelanggan"
) ?>

</div>

</header>


<section class="content">

<div class="page-title">

<h1>
Keranjang Belanja
</h1>

<p>
Produk yang akan Anda beli.
</p>

</div>


<div class="table-card">


<?php if (!$items): ?>

<div class="empty">

<h2>
Keranjang masih kosong
</h2>

<p>
Silakan pilih produk terlebih dahulu.
</p>

<a
href="customer/products.php"
class="btn primary">

Belanja Sekarang

</a>

</div>


<?php else: ?>


<form method="POST">

<table>

<thead>

<tr>

<th>
Produk
</th>

<th>
Harga
</th>

<th>
Jumlah
</th>

<th>
Subtotal
</th>

<th>
Aksi
</th>

</tr>

</thead>


<tbody>


<?php foreach (
$items as $item
): ?>


<tr>

<td class="product-cell">

<img
src="<?=

$item["image"]
?
$item["image"]
:
"assets/images/logo.jpg"

?>">

<span>

<?= htmlspecialchars(
$item["name"]
) ?>

</span>

</td>


<td>

Rp
<?= number_format(
$item["price"],
0,
",",
"."
) ?>

</td>


<td>

<input
class="qty"
type="number"
min="1"
name="qty[
<?= $item["id"] ?>
]"
value="<?= $item["qty"] ?>">

</td>


<td>

Rp
<?= number_format(
$item["subtotal"],
0,
",",
"."
) ?>

</td>


<td>

<a
class="danger-link"
href="cart.php?remove=
<?= $item["id"] ?>">

Hapus

</a>

</td>

</tr>


<?php endforeach; ?>


</tbody>

</table>


<div class="cart-bottom">

<button
type="submit"
class="btn secondary">

Update Keranjang

</button>


<h2>

Total:

Rp
<?= number_format(
$total,
0,
",",
"."
) ?>

</h2>

</div>


</form>


<a
href="checkout.php"
class="btn primary">

Lanjut Checkout →

</a>


<?php endif; ?>


</div>

</section>

</main>

</div>

</body>

</html>