create database sri_tani_rejeki;
use sri_tani_rejeki;

create table produk (
    id INT auto_increment primary key,
    nama_produk varchar(100) not null,
    kategori varchar(100) not null,
    harga decimal (15,2) not null,
    stok INT not null default 0,
    deskripsi text,
    foto varchar(255),
    created_at timestamp default current_timestamp
);

insert into produk
(nama_produk, kategori, harga, stok, deskripsi, foto) values
('Pupuk NPK 16-16-16','Pupuk', 20000, 25, 'pupuk NPK untuk membantu pertumbuhan tanaman.','Pupuk-NPK.jpg'),
('Pupuk Kalsika', 'Pupuk', 30000, 20, 'Untuk memperkuat batang serta daun tanaman.', 'Pupuk-Kalsika.jpg'),
('Pupuk Ultradap', 'Pupuk', 58000, 15, 'Untuk mempercepat pembentukan bunga pada tanaman.', 'Pupuk-Ultradap.jpg'),
('Metindo 40 SP','Insektisida',35000, 15, 'Untuk membasmi, mengusir atau mengendalikan populasi serangga.', 'Metindo.jpg'),
('Dangke 40 WP', 'Insektisida', 65000, 20, 'Untuk membasmi hama serangga seperti ulat.', 'Dangke.jpg'),
('Furadan 3 GR', 'Insektisida', 28000, 40, 'Untuk obat atau racun pembasmi hama tanaman.', 'Furadan.jpg'),
('Klopindo 10 WP', 'Insektisida', 25000, 30, 'Untuk mengendalikan hama serangga penghisap pada tanaman.', 'Klopindo.jpg'),
('Metsulindo Plus 80 WP', 'Obat Rumput', 13000, 25, 'Untuk membasmi rumput liar pada tanaman padi.', 'Metsulindo.jpg'),
('Noxone','Obat Rumput',70000, 15,'Untuk membasmi rumput liar dan gulma.','Noxone.jpg'),
('Lae Up','Obat Rumput',85000,10,'Untuk membunuh dan mengendalikan gulma hingga ke akar.','LaeUp.jpg'),
('Himaquad','Obat Rumput',60000,12,'Untuk membasmi gulma dan rumput liar secara cepat.','Himaquad.jpg'),
('Bhirawa','Benih Tanaman',20000,16,'Sebagai varietas tanaman buncis.','Bhirawa.jpg'),
('Sawitri','Benih Tanaman',18000,20,'Sebagai bibit tanaman kangkung.','Sawitri.jpg');